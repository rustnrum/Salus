# SALUS by Rust N Rum

**Milestone 1 — Home graphics ONLY (Flutter / Android).**

This is a genuinely new Flutter application with one designed, scrollable Home page. It is not a clone of HealthyMe-Beta. **No Bluetooth, Health Connect, AI, network API, scores, logins, or other module screens are implemented.** All health values are explicitly empty and the decorative charts have no fictional data points.

## Screen design

The dark SALUS Home / Recovery concept supplied for the project (the mountain-backed screen) is the visual direction. The other Nutrition and Training examples are future inspiration only. The implementation is drawn with standard Flutter widgets and Dart `CustomPainter`, including the mountain layers, ring, empty-state grid, atmospheric gradients, and color accents. It is an interpretation of the reference, **not a pixel-exact copy of a composite promotional render**. No bitmap image or Python source is involved.

- One page: `SalusHomePage`
- Narrow Z Fold cover display: compact stacked layout
- Wider unfolded Z Fold display: a two-column overview
- Stable SafeArea and non-overlapping bottom navigation
- Decorative navigation only; no dead links to unfinished pages
- Distinct `DESIGN PREVIEW` label and data values shown as `—`
- Only Flutter and Dart for app logic and graphics

## Repo contents

```
salus/
├── lib/
│   ├── main.dart
│   ├── design/salus_palette.dart
│   ├── graphics/mountain_backdrop.dart
│   ├── graphics/preview_charts.dart
│   ├── widgets/glass_panel.dart
│   └── home/salus_home_page.dart
├── test/home_page_test.dart
├── test_goldens/home_snapshots_test.dart
├── android/app/build.gradle.kts
├── android/app/src/main/AndroidManifest.xml
├── .github/workflows/android-verify.yml
├── .github/workflows/android-release.yml
├── pubspec.yaml
├── analysis_options.yaml
└── .gitignore
```

### Why the Android directory is not fully expanded

The Flutter SDK provides platform-specific generated Android wrapper files that should match the installed Flutter release. The workflow **generates the remaining conventional platform scaffold** on the runner using `flutter create`. This avoids incorrectly mixing Gradle bootstrap files from older Flutter versions. The two Android override files in this repo preserve the SALUS ID, label, and signed-release configuration. The app's interface and graphical drawing code is Dart only; Gradle, YAML and AndroidManifest are unavoidable build metadata, not additional app languages.

After you download/clone, with a current stable Flutter SDK installed, run:

```bash
flutter create --platforms=android --org com.rustnrum --project-name salus .
flutter pub get
flutter analyze
flutter test test/
flutter run
```

Application ID: `com.rustnrum.salus` — coexists with HealthyMe-Beta.

## GitHub Actions

1. **Salus | Verify & Debug APK** triggers automatically when files reach `main`. It creates the standard Android scaffold, analyzes Dart, runs three screen-size tests plus content checks, captures screenshot goldens for 360×780 and 820×900, and builds an installable debug APK. Download `salus-home-preview-debug-apk` and `salus-home-screenshots` from that run's **Artifacts** section. These screenshots are **CI renderings, not Samsung phone captures**.
2. **Salus | Signed Release APK** runs manually after the four signing secrets are installed. It runs checks then exports signed APK and AAB in `salus-home-signed-release`.

**Never upload the `.p12` keystore, passwords, secret-text file or `android/key.properties` to the public GitHub repository.** The signed app must always use the same key across versions to support in-place updates. Keep the original private keystore safe.

### Signing secrets (GitHub repository Settings → Secrets and variables → Actions)

- `SALUS_KEYSTORE_BASE64` — the entire base64 representation of your permanent `.p12` keystore, provided separately.
- `SALUS_STORE_PASSWORD` — provided separately.
- `SALUS_KEY_PASSWORD` — same password as store password for the supplied PKCS12 key.
- `SALUS_KEY_ALIAS` — `salusupload`.

These secrets are *not* included in the publicly shared GitHub source tree. Never generate a new upload key just to fix a build issue.

## Milestone status

- Source composed: **yes**
- Source uploaded to GitHub: **not implied by this file; verify repository commits**
- GitHub CI and Flutter `analyze` / `test`: **pending first runner execution**
- Rendered reference screen approval: **pending**
- Actual Fold 7 folded/unfolded device testing: **pending**
- Any health data implementation: **intentionally absent**

**Rule:** Design → Build → Test → Review → Approve → Next page.

## Initial GitHub upload

GitHub confirmed that `rustnrum/Salus` exists, but the connected integration returned **HTTP 403 Forbidden** when trying to write source into it. To initialize it manually:

1. Extract `Salus-Home-Page-SOURCE.zip` **outside** GitHub.
2. Open [rustnrum/Salus](https://github.com/rustnrum/Salus) and use **Add file → Upload files** on the `main` branch (desktop browser is easiest).
3. Upload **the contents of the extracted `salus` directory**, preserving its subdirectories and `.github/workflows` folder. Do **not** upload the ZIP as the only repository file; GitHub does not automatically unpack archives into a repository tree.
4. Commit directly to `main`. GitHub Actions should then run **Salus | Verify & Debug APK**. Wait for a green run before treating the build as installable.

Keep the signing files completely outside the repo; use their values only in GitHub Actions **Secrets**. If uploading from a phone cannot preserve the folder structure, use GitHub Desktop or a desktop browser to avoid flattening the paths.
