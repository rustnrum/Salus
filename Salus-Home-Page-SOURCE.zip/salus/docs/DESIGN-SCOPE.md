# Salus Home — first-screen design boundaries

Primary reference: the user's **dark SALUS mountain + Recovery** promotional mockup (fourth attached image). The light Home concept and the training/nutrition mockups are references for later pages, not additional pages to generate now.

**Designed on Home**: logo, mountain background, status, large headline, Recovery gauge empty state, Sleep/HRV/RHR/Energy/Activity factors, metric tile grid, empty chart grid, insights panel, bottom-nav preview.

**No actions**: bottom-nav graphics do not navigate; notification icon is only a graphic; empty-state recovery is intentionally not estimated; there are no made-up dates or tracked entries beyond the device date.

**Review needed**: check on Fold cover and main screen, including expanded text-scale and long labels. Compare typography, color, artwork, card spacing, chart readability and fixed bottom nav against references before moving to live Health Connect.
