import 'package:flutter/material.dart';

abstract final class SalusPalette {
  static const Color ink = Color(0xFF061018);
  static const Color deep = Color(0xFF0B1B29);
  static const Color slate = Color(0xFF162737);
  static const Color canvas = Color(0xFF101F2E);
  static const Color mist = Color(0xFFDFEFF2);
  static const Color muted = Color(0xFF8FA4B4);
  static const Color mint = Color(0xFF36DFAD);
  static const Color cyan = Color(0xFF37C7F4);
  static const Color blue = Color(0xFF598EF8);
  static const Color violet = Color(0xFFB38CFF);
  static const Color coral = Color(0xFFFF7488);
  static const Color amber = Color(0xFFFFBA68);
  static const Color chartGrid = Color(0xFF294153);
}
