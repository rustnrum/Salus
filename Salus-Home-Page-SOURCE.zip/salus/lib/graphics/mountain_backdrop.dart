import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../design/salus_palette.dart';

/// Entirely Dart/Canvas atmospheric landscape. No network or image assets.
/// Art is decorative: it is never used to impersonate a health measurement.
class MountainBackdrop extends StatelessWidget {
  const MountainBackdrop({super.key});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: CustomPaint(
          painter: _MountainPainter(),
          size: Size.infinite,
        ),
      ),
    );
  }
}

class _MountainPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final background = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF0C2336), Color(0xFF112D42), Color(0xFF07111C)],
        stops: [0, .52, 1],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, background);

    // Diffuse sunset and deep cyan atmospheric haze.
    final lightCenter = Offset(size.width * .83, 210);
    final lightRadius = math.max(size.width * .85, 420.0);
    canvas.drawCircle(
      lightCenter,
      lightRadius,
      Paint()
        ..shader = RadialGradient(
          colors: [
            const Color(0xFFC8A083).withValues(alpha: .45),
            const Color(0xFF416D8A).withValues(alpha: .21),
            Colors.transparent,
          ],
          stops: const [0, .27, .8],
        ).createShader(Rect.fromCircle(center: lightCenter, radius: lightRadius)),
    );

    // The geometry is scale independent; both Z Fold displays see the horizon.
    final horizon = math.min(335.0, size.height * .47);
    _ridge(
      canvas,
      size,
      horizon,
      const [0, .23, .37, .48, .60, .72, .87, 1],
      const [.83, .43, .67, .24, .51, .15, .59, .75],
      const [Color(0xFF72869A), Color(0xFF253E56)],
    );
    _ridge(
      canvas,
      size,
      horizon + 47,
      const [0, .13, .25, .33, .45, .57, .66, .80, .91, 1],
      const [.51, .74, .37, .63, .29, .69, .42, .18, .57, .52],
      const [Color(0xFF355169), Color(0xFF152B3D)],
    );
    _ridge(
      canvas,
      size,
      horizon + 87,
      const [0, .15, .28, .40, .56, .68, .81, 1],
      const [.39, .69, .52, .87, .42, .76, .47, .60],
      const [Color(0xFF182D3D), Color(0xFF071723)],
    );

    // Snow light catching a peak, with no bitmap or hidden asset.
    final snow = Path()
      ..moveTo(size.width * .715, horizon - 31)
      ..lineTo(size.width * .72, horizon - 51)
      ..lineTo(size.width * .752, horizon - 23)
      ..lineTo(size.width * .74, horizon - 30)
      ..lineTo(size.width * .727, horizon - 26)
      ..close();
    canvas.drawPath(snow, Paint()..color = const Color(0xFFDBE4E9).withValues(alpha: .38));

    // Fade any terrain before the first row of readable content.
    canvas.drawRect(
      Rect.fromLTWH(0, 170, size.width, size.height - 170),
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.transparent, Color(0xDF061018), SalusPalette.ink],
          stops: [0, .35, 1],
        ).createShader(Rect.fromLTWH(0, 170, size.width, size.height - 170)),
    );

    final random = math.Random(77);
    final speckle = Paint()..color = Colors.white.withValues(alpha: .12);
    for (var i = 0; i < 65; i++) {
      final x = size.width * random.nextDouble();
      final y = random.nextDouble() * math.min(360, size.height * .36);
      canvas.drawCircle(Offset(x, y), .2 + random.nextDouble() * .65, speckle);
    }
  }

  void _ridge(
    Canvas canvas,
    Size size,
    double y,
    List<double> xs,
    List<double> relativeHeights,
    List<Color> colors,
  ) {
    final path = Path()..moveTo(0, size.height);
    path.lineTo(0, y - relativeHeights.first * 90);
    for (var i = 1; i < xs.length; i++) {
      path.lineTo(xs[i] * size.width, y - relativeHeights[i] * 135);
    }
    path
      ..lineTo(size.width, size.height)
      ..close();
    canvas.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: colors,
        ).createShader(Rect.fromLTWH(0, y - 150, size.width, size.height - y + 150)),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
