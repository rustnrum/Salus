import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../design/salus_palette.dart';

class RecoveryRing extends StatelessWidget {
  const RecoveryRing({super.key, this.diameter = 170});
  final double diameter;

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: diameter,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomPaint(
            size: Size.square(diameter),
            painter: const _RecoveryRingPainter(),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '—',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: diameter * .28,
                  height: 1,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 2),
              const Text(
                'NO DATA',
                style: TextStyle(
                  color: SalusPalette.muted,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.6,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _RecoveryRingPainter extends CustomPainter {
  const _RecoveryRingPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final middle = size.center(Offset.zero);
    final radius = size.shortestSide * .405;
    final track = Rect.fromCircle(center: middle, radius: radius);
    final base = Paint()
      ..color = SalusPalette.slate
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.shortestSide * .072
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(track, -math.pi * .79, math.pi * 1.58, false, base);

    // Open-ended, decorative accents — deliberately NOT a percentage gauge.
    const swatches = [
      SalusPalette.mint,
      SalusPalette.cyan,
      SalusPalette.blue,
    ];
    for (var i = 0; i < 3; i++) {
      final paint = Paint()
        ..color = swatches[i].withValues(alpha: .65)
        ..style = PaintingStyle.stroke
        ..strokeWidth = size.shortestSide * .072
        ..strokeCap = StrokeCap.round
        ..maskFilter = MaskFilter.blur(BlurStyle.solid, size.shortestSide * .004);
      canvas.drawArc(
        track,
        -math.pi * .78 + i * .45,
        .31,
        false,
        paint,
      );
    }
    canvas.drawCircle(
      middle,
      size.shortestSide * .284,
      Paint()
        ..color = SalusPalette.ink.withValues(alpha: .34)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class GhostTrendChart extends StatelessWidget {
  const GhostTrendChart({super.key, this.height = 138});
  final double height;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned.fill(
            child: CustomPaint(painter: const _GridPainter()),
          ),
          const DecoratedBox(
            decoration: BoxDecoration(
              color: Color(0xCC0D1B28),
              borderRadius: BorderRadius.all(Radius.circular(9)),
            ),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 15, vertical: 9),
              child: Text(
                'No measurements yet',
                style: TextStyle(
                  color: SalusPalette.mist,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  const _GridPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final linePaint = Paint()
      ..color = SalusPalette.chartGrid.withValues(alpha: .58)
      ..strokeWidth = .8;
    for (var row = 0; row < 5; row++) {
      final y = 7 + (size.height - 14) * row / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), linePaint);
    }
    for (var col = 0; col < 7; col++) {
      final x = (size.width - 1) * col / 6;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), linePaint);
    }
    // Slight haze is just visual atmosphere; no fabricated plot line.
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0x0300E4C5), Color(0x110AB9C2)],
        ).createShader(Offset.zero & size),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class DecorativeBars extends StatelessWidget {
  const DecorativeBars({super.key, required this.color});
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: List.generate(13, (index) {
        final levels = [9.0, 17.0, 13.0, 22.0, 15.0, 18.0, 11.0, 25.0, 16.0, 20.0, 12.0, 15.0, 10.0];
        return Expanded(
          child: Padding(
            padding: const EdgeInsets.only(right: 3),
            child: Container(
              height: levels[index],
              decoration: BoxDecoration(
                color: color.withValues(alpha: .13 + (index % 3) * .025),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(3)),
              ),
            ),
          ),
        );
      }),
    );
  }
}
