import 'package:flutter/material.dart';

import '../design/salus_palette.dart';
import '../graphics/mountain_backdrop.dart';
import '../graphics/preview_charts.dart';
import '../widgets/glass_panel.dart';

/// Milestone 1: a single, intentional design-preview page.
/// No health integrations, other routes, fake sensor numbers, or requests.
class SalusHomePage extends StatelessWidget {
  const SalusHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SalusPalette.ink,
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          const Positioned.fill(child: MountainBackdrop()),
          SafeArea(
            bottom: false,
            child: LayoutBuilder(
              builder: (context, constraints) {
                final available = constraints.maxWidth;
                final expanded = available >= 640;
                final margin = available < 370 ? 15.0 : (expanded ? 28.0 : 20.0);
                return CustomScrollView(
                  key: const Key('salus-home-scroll'),
                  slivers: [
                    SliverToBoxAdapter(
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 1140),
                          child: Padding(
                            padding: EdgeInsets.fromLTRB(margin, 10, margin, 26),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const _SalusHeader(),
                                const SizedBox(height: 30),
                                const _Introduction(),
                                SizedBox(height: expanded ? 31 : 26),
                                if (expanded)
                                  const _ExpandedHome()
                                else
                                  const _CompactHome(),
                                const SizedBox(height: 22),
                                const Center(
                                  child: Text(
                                    'SALUS  •  RUST N RUM  •  CONCEPT 01',
                                    style: TextStyle(
                                      color: Color(0xFF567081),
                                      fontSize: 9,
                                      letterSpacing: 2.1,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: const _BottomNavigationPreview(),
    );
  }
}

class _SalusHeader extends StatelessWidget {
  const _SalusHeader();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Text(
          'SΛLUS',
          style: TextStyle(
            fontSize: 25,
            height: 1,
            color: Colors.white,
            letterSpacing: 6,
            fontWeight: FontWeight.w500,
          ),
        ),
        const Spacer(),
        const PreviewPill(),
        const SizedBox(width: 12),
        Container(
          width: 35,
          height: 35,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white.withValues(alpha: .23)),
            color: Colors.white.withValues(alpha: .05),
          ),
          alignment: Alignment.center,
          child: const Icon(Icons.notifications_none_rounded, color: SalusPalette.mist, size: 19),
        ),
      ],
    );
  }
}

class _Introduction extends StatelessWidget {
  const _Introduction();

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December',
    ];
    final today = '${months[now.month - 1]} ${now.day}, ${now.year}';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 16,
              height: 2,
              decoration: BoxDecoration(
                color: SalusPalette.cyan,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 10),
            Text(
              today.toUpperCase(),
              style: const TextStyle(
                color: SalusPalette.mist,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.7,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        const Text(
          'Your whole health,\nin focus.',
          style: TextStyle(
            color: Colors.white,
            fontSize: 36,
            height: 1.09,
            fontWeight: FontWeight.w800,
            letterSpacing: -.9,
            shadows: [Shadow(color: Color(0x88000000), blurRadius: 22)],
          ),
        ),
        const SizedBox(height: 11),
        const Text(
          'A clearer picture of how you move, recover and live.',
          style: TextStyle(color: Color(0xFFCCDCE4), fontSize: 13, height: 1.42),
        ),
      ],
    );
  }
}

class _CompactHome extends StatelessWidget {
  const _CompactHome();

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _RecoveryPanel(),
        SizedBox(height: 23),
        _SectionTitle('Today’s overview', subtitle: 'A preview of your future dashboard'),
        SizedBox(height: 13),
        _MetricGrid(),
        SizedBox(height: 23),
        _TrendPanel(),
        SizedBox(height: 16),
        _InsightPanel(),
      ],
    );
  }
}

class _ExpandedHome extends StatelessWidget {
  const _ExpandedHome();

  @override
  Widget build(BuildContext context) {
    return const Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 11,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _RecoveryPanel(),
              SizedBox(height: 18),
              _InsightPanel(),
            ],
          ),
        ),
        SizedBox(width: 20),
        Expanded(
          flex: 12,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _SectionTitle('Today’s overview', subtitle: 'Your dashboard at a glance'),
              SizedBox(height: 13),
              _MetricGrid(),
              SizedBox(height: 18),
              _TrendPanel(),
            ],
          ),
        ),
      ],
    );
  }
}

class _RecoveryPanel extends StatelessWidget {
  const _RecoveryPanel();

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      padding: const EdgeInsets.fromLTRB(17, 18, 17, 16),
      accent: SalusPalette.mint,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.auto_awesome, size: 19, color: SalusPalette.mint),
              SizedBox(width: 9),
              Expanded(
                child: Text(
                  'Recovery',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17),
                ),
              ),
              Icon(Icons.info_outline, size: 16, color: SalusPalette.muted),
            ],
          ),
          const SizedBox(height: 5),
          const Text(
            'Personalized readiness — available later',
            style: TextStyle(color: SalusPalette.muted, fontSize: 11.5),
          ),
          const SizedBox(height: 14),
          LayoutBuilder(
            builder: (context, constraints) {
              final useColumn = constraints.maxWidth < 292;
              const ring = RecoveryRing(diameter: 146);
              const factors = _RecoveryFactors();
              return useColumn
                  ? const Column(children: [ring, SizedBox(height: 8), factors])
                  : const Row(
                      children: [
                        ring,
                        SizedBox(width: 12),
                        Expanded(child: factors),
                      ],
                    );
            },
          ),
          const SizedBox(height: 15),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: SalusPalette.mint.withValues(alpha: .07),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: SalusPalette.mint.withValues(alpha: .16)),
            ),
            child: const Row(
              children: [
                Icon(Icons.shield_outlined, color: SalusPalette.mint, size: 18),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'No score until real inputs are available.',
                    style: TextStyle(color: Color(0xFFC1EADF), fontSize: 11.5, height: 1.35),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RecoveryFactors extends StatelessWidget {
  const _RecoveryFactors();

  @override
  Widget build(BuildContext context) {
    return const Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _FactorRow(icon: Icons.bedtime_outlined, label: 'Sleep', color: SalusPalette.blue),
        SizedBox(height: 14),
        _FactorRow(icon: Icons.multiline_chart, label: 'HRV', color: SalusPalette.violet),
        SizedBox(height: 14),
        _FactorRow(icon: Icons.favorite_border, label: 'Resting HR', color: SalusPalette.coral),
        SizedBox(height: 14),
        _FactorRow(icon: Icons.bolt_outlined, label: 'Energy', color: SalusPalette.amber),
        SizedBox(height: 14),
        _FactorRow(icon: Icons.directions_run_rounded, label: 'Activity', color: SalusPalette.cyan),
      ],
    );
  }
}

class _FactorRow extends StatelessWidget {
  const _FactorRow({required this.icon, required this.label, required this.color});
  final IconData icon;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(width: 7),
        Expanded(
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Color(0xFFC8D8E2), fontSize: 11),
          ),
        ),
        const Text('—', style: TextStyle(color: SalusPalette.muted, fontSize: 15)),
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.title, {required this.subtitle});
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: SalusPalette.muted, fontSize: 11.5)),
      ],
    );
  }
}

class _MetricGrid extends StatelessWidget {
  const _MetricGrid();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: _buildMetrics,
    );
  }

  static Widget _buildMetrics(BuildContext context, BoxConstraints constraints) {
    final cols = constraints.maxWidth >= 520 ? 3 : 2;
    const gap = 11.0;
    final tileWidth = (constraints.maxWidth - (cols - 1) * gap) / cols;
    return Wrap(
      spacing: gap,
      runSpacing: gap,
      children: [
        _MetricCard(width: tileWidth, title: 'Sleep', icon: Icons.bedtime_outlined,
            color: SalusPalette.blue, unit: 'duration'),
        _MetricCard(width: tileWidth, title: 'Heart & HRV', icon: Icons.favorite_border,
            color: SalusPalette.coral, unit: 'bpm · ms'),
        _MetricCard(width: tileWidth, title: 'Activity', icon: Icons.directions_walk_outlined,
            color: SalusPalette.cyan, unit: 'steps'),
        _MetricCard(width: tileWidth, title: 'Energy', icon: Icons.bolt_outlined,
            color: SalusPalette.amber, unit: 'readiness'),
        _MetricCard(width: tileWidth, title: 'Nutrition', icon: Icons.restaurant_outlined,
            color: SalusPalette.mint, unit: 'daily intake'),
        _MetricCard(width: tileWidth, title: 'Wellbeing', icon: Icons.spa_outlined,
            color: SalusPalette.violet, unit: 'check-in'),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.width,
    required this.title,
    required this.icon,
    required this.color,
    required this.unit,
  });
  final double width;
  final String title;
  final IconData icon;
  final Color color;
  final String unit;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: GlassPanel(
        padding: const EdgeInsets.fromLTRB(13, 14, 13, 12),
        radius: 18,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 18),
                const SizedBox(width: 7),
                Expanded(
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 15),
            Text(
              '—',
              style: TextStyle(fontSize: 26, height: 1, color: color, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 3),
            Text(unit, style: const TextStyle(color: SalusPalette.muted, fontSize: 10)),
            const SizedBox(height: 13),
            SizedBox(height: 26, child: DecorativeBars(color: color)),
          ],
        ),
      ),
    );
  }
}

class _TrendPanel extends StatelessWidget {
  const _TrendPanel();

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.show_chart_rounded, color: SalusPalette.cyan, size: 20),
              SizedBox(width: 9),
              Expanded(
                child: Text('Health trends', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              ),
              Text('7D', style: TextStyle(color: SalusPalette.muted, fontSize: 11)),
            ],
          ),
          const SizedBox(height: 8),
          const Text('Charts will use real times, sources and units.',
              style: TextStyle(color: SalusPalette.muted, fontSize: 11)),
          const SizedBox(height: 15),
          const GhostTrendChart(height: 134),
          const SizedBox(height: 12),
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('MON', style: TextStyle(color: SalusPalette.muted, fontSize: 9)),
              Text('WED', style: TextStyle(color: SalusPalette.muted, fontSize: 9)),
              Text('FRI', style: TextStyle(color: SalusPalette.muted, fontSize: 9)),
              Text('SUN', style: TextStyle(color: SalusPalette.muted, fontSize: 9)),
            ],
          ),
        ],
      ),
    );
  }
}

class _InsightPanel extends StatelessWidget {
  const _InsightPanel();

  @override
  Widget build(BuildContext context) {
    return GlassPanel(
      padding: const EdgeInsets.all(17),
      accent: SalusPalette.cyan,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.auto_awesome_outlined, color: SalusPalette.violet, size: 20),
              SizedBox(width: 9),
              Text('Your insights', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            ],
          ),
          const SizedBox(height: 11),
          const Text(
            'A thoughtful daily summary will live here — based on the measurements you choose to share.',
            style: TextStyle(color: Color(0xFFD0E2E9), fontSize: 12, height: 1.5),
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 13),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: LinearGradient(
                colors: [SalusPalette.cyan.withValues(alpha: .22), SalusPalette.mint.withValues(alpha: .09)],
              ),
              border: Border.all(color: SalusPalette.cyan.withValues(alpha: .31)),
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.lock_outline_rounded, color: SalusPalette.cyan, size: 15),
                SizedBox(width: 8),
                Flexible(
                  child: Text(
                    'Connections arrive after design approval',
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Color(0xFFE4F9FC), fontSize: 11, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BottomNavigationPreview extends StatelessWidget {
  const _BottomNavigationPreview();

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xF9081520),
        border: Border(top: BorderSide(color: Colors.white.withValues(alpha: .09))),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: .28), blurRadius: 24),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(10, 8, 10, 7),
          child: Row(
            children: const [
              _NavPreviewItem(icon: Icons.home_rounded, label: 'Home', selected: true),
              _NavPreviewItem(icon: Icons.favorite_outline_rounded, label: 'Health'),
              _NavPreviewItem(icon: Icons.fitness_center_rounded, label: 'Training'),
              _NavPreviewItem(icon: Icons.restaurant_menu_rounded, label: 'Nutrition'),
              _NavPreviewItem(icon: Icons.grid_view_outlined, label: 'More'),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavPreviewItem extends StatelessWidget {
  const _NavPreviewItem({required this.icon, required this.label, this.selected = false});
  final IconData icon;
  final String label;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Semantics(
        label: '$label navigation preview${selected ? ', current section' : ''}',
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: selected ? SalusPalette.cyan : SalusPalette.muted, size: 22),
            const SizedBox(height: 5),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: selected ? Colors.white : SalusPalette.muted,
                fontSize: 10,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
              ),
            ),
            const SizedBox(height: 4),
            AnimatedContainer(
              duration: const Duration(milliseconds: 260),
              height: 2,
              width: selected ? 22 : 0,
              decoration: BoxDecoration(color: SalusPalette.cyan, borderRadius: BorderRadius.circular(5)),
            ),
          ],
        ),
      ),
    );
  }
}
