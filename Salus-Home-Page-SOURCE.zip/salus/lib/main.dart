import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'home/salus_home_page.dart';
import 'design/salus_palette.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: SalusPalette.ink,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const SalusApp());
}

class SalusApp extends StatelessWidget {
  const SalusApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SALUS',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: SalusPalette.ink,
        colorScheme: ColorScheme.fromSeed(
          seedColor: SalusPalette.mint,
          brightness: Brightness.dark,
          surface: SalusPalette.ink,
        ),
        textTheme: const TextTheme(
          headlineLarge: TextStyle(fontWeight: FontWeight.w800, height: 1.10),
          headlineMedium: TextStyle(fontWeight: FontWeight.w800, height: 1.12),
          titleLarge: TextStyle(fontWeight: FontWeight.w700),
          titleMedium: TextStyle(fontWeight: FontWeight.w700),
          bodyMedium: TextStyle(height: 1.36),
        ),
      ),
      home: const SalusHomePage(),
    );
  }
}
