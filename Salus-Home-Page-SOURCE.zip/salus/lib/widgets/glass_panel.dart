import 'package:flutter/material.dart';

import '../design/salus_palette.dart';

class GlassPanel extends StatelessWidget {
  const GlassPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.radius = 22,
    this.accent,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final Color? accent;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xEF1A3142), Color(0xF4101C2A), Color(0xF30A1723)],
          stops: [0, .52, 1],
        ),
        border: Border.all(
          color: accent?.withValues(alpha: .32) ?? Colors.white.withValues(alpha: .10),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: .18),
            blurRadius: 26,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Padding(padding: padding, child: child),
    );
  }
}

class PreviewPill extends StatelessWidget {
  const PreviewPill({super.key, this.text = 'DESIGN PREVIEW'});
  final String text;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: SalusPalette.cyan.withValues(alpha: .10),
        border: Border.all(color: SalusPalette.cyan.withValues(alpha: .35)),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
        child: Text(
          text,
          style: const TextStyle(
            color: SalusPalette.cyan,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
            fontSize: 9,
          ),
        ),
      ),
    );
  }
}
