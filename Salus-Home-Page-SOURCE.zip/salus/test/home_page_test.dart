import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:salus/main.dart';

Future<void> openAtSize(WidgetTester tester, Size size) async {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1;
  addTearDown(() {
    tester.view.resetPhysicalSize();
    tester.view.resetDevicePixelRatio();
  });
  await tester.pumpWidget(const SalusApp());
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('folded: the Home page renders without layout exceptions', (tester) async {
    await openAtSize(tester, const Size(360, 780));
    expect(find.text('DESIGN PREVIEW'), findsOneWidget);
    expect(find.text('Recovery'), findsOneWidget);
    expect(find.text('NO DATA'), findsOneWidget);
    expect(find.text('No score until real inputs are available.'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('unfolded: content rearranges into two columns', (tester) async {
    await openAtSize(tester, const Size(820, 900));
    expect(find.text('Today’s overview'), findsOneWidget);
    expect(find.text('Your insights'), findsOneWidget);
    expect(find.text('Health trends'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('small view: navigation labels are present without overflowing', (tester) async {
    await openAtSize(tester, const Size(320, 700));
    expect(find.text('PREVIEW'), findsOneWidget);
    expect(find.text('Home'), findsOneWidget);
    expect(find.text('Training'), findsOneWidget);
    expect(find.text('Nutrition'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('no unapproved functional modules or false readings', (tester) async {
    await openAtSize(tester, const Size(390, 844));
    expect(find.byType(TextField), findsNothing);
    expect(find.text('82'), findsNothing);
    expect(find.text('72 ms'), findsNothing);
    expect(find.text('Health Connect'), findsNothing);
    expect(find.text('—'), findsWidgets);
  });
}
