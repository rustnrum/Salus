import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:salus/main.dart';

void main() {
  testWidgets('Home design opens instead of the Flutter counter template',
      (tester) async {
    await tester.pumpWidget(const SalusApp());
    await tester.pumpAndSettle();
    expect(find.byType(MaterialApp), findsOneWidget);
    expect(find.text('Recovery'), findsOneWidget);
    expect(find.text('DESIGN PREVIEW'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
