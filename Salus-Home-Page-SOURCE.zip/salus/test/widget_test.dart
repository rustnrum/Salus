import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:salus/main.dart';

void main() {
  testWidgets('SALUS opens its Home design preview', (tester) async {
    await tester.pumpWidget(const SalusApp());
    expect(find.text('Recovery'), findsOneWidget);
    expect(find.text('DESIGN PREVIEW'), findsOneWidget);
    expect(find.byType(MaterialApp), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
