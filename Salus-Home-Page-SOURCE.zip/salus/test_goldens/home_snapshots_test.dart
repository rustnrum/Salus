// Optional screenshot capture (NOT run by the normal `flutter test` suite).
// Capture from CI: flutter test --update-goldens test_goldens/home_snapshots_test.dart
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:salus/main.dart';

void main() {
  for (final device in <(String, Size)>[
    ('folded', const Size(360, 780)),
    ('unfolded', const Size(820, 900)),
  ]) {
    testWidgets('Capture ${device.$1} Home', (tester) async {
      tester.view.physicalSize = device.$2;
      tester.view.devicePixelRatio = 1;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });
      await tester.pumpWidget(const SalusApp());
      await tester.pumpAndSettle();
      await expectLater(
        find.byType(MaterialApp),
        matchesGoldenFile('goldens/salus-home-${device.$1}.png'),
      );
    });
  }
}
